
const { test, expect } = require('@playwright/test');

test('LaundrySIA application is reachable', async ({ page }) => {
  const errors = [];

  page.on('pageerror', error => {
    errors.push(error.message);
  });

  const response = await page.goto('/');

  // Verify the server responded successfully.
  expect(response).not.toBeNull();
  expect(response.status()).toBeLessThan(400);

  // Verify the LaundrySIA application is visible.
  await expect(page.locator('body')).toContainText(/LaundrySIA/i);

  // Verify there are no uncaught JavaScript errors.
  expect(errors).toEqual([]);
});
